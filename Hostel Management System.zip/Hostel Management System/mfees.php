<?php
echo '<body>
<div align="center">
<h1 style="color:#414040"><u>MESS FEES</u></h1>
<form method="POST">
<select name="mess" class="form-control" required="required" style="height:40px; font-weight:bold; font-size:20px">
<option value="">Select Mess</option>
<option value="1">Annapurna Caterers</option>
<option value="2">Aditya Caterers</option>
<option value="3">Manikanta Caterers</option>
</select>
<input type="submit" name="submit" Value="Get Mess Fee" class="btn btn-primary" style="height:40px; font-weight:bold; font-size:20px">
</form>
</div>
</body>';
if(isset($_POST['submit']))
{
	$mess=$_POST['mess'];
	if($mess==1)
	{
		$con=mysqli_connect("localhost","root","padmaja11@","hostel");
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		$query1="SELECT total from messfee where messid=1";
		$result1=mysqli_query($con,$query1);
		$query2="SELECT milk from messfee where messid=1";
		$result2=mysqli_query($con,$query2);
		$query3="SELECT nonveg from messfee where messid=1";
		$result3=mysqli_query($con,$query3);
		$query4="SELECT icensweet from messfee where messid=1";
		$result4=mysqli_query($con,$query4);
		$query5="SELECT softdrinks from messfee where messid=1";
		$result5=mysqli_query($con,$query5);
		$query6="SELECT roomservings from messfee where messid=1";
		$result6=mysqli_query($con,$query6);
		
		echo "
		<div align='center'>
		<table width='1058' height='20' border='0'>
		
		<h2 style='color:#414040'><u>ANNAPURNA CATERERS</u></h2>
		";
		while($row=mysqli_fetch_array($result1))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Total Mess Fees:</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['total']."/-</center></td>";
			echo "</tr></table>";
		}

		while($row=mysqli_fetch_array($result2))
		{
			echo "<table width='1058' height='204' border='0'>
			<h2 style='color:#414040'><u>Additional Charges(not mandatory)</u></h2>
			<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Milk Charges(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['milk']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result3))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Non Veg Charges(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['nonveg']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result4))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Icecreams and Sweets(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['icensweet']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result5))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Soft Drinks(per occasion):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['softdrinks']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result6))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Room Servings(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['roomservings']."/-</center></td>";
			echo "</tr>";
		}
		echo "</table></div>";
	}


	if($mess==2)
	{
		$con=mysqli_connect("localhost","root","padmaja11@","hostel");
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		$query1="SELECT total from messfee where messid=2";
		$result1=mysqli_query($con,$query1);
		$query2="SELECT milk from messfee where messid=2";
		$result2=mysqli_query($con,$query2);
		$query3="SELECT nonveg from messfee where messid=2";
		$result3=mysqli_query($con,$query3);
		$query4="SELECT icensweet from messfee where messid=2";
		$result4=mysqli_query($con,$query4);
		$query5="SELECT softdrinks from messfee where messid=2";
		$result5=mysqli_query($con,$query5);
		$query6="SELECT roomservings from messfee where messid=2";
		$result6=mysqli_query($con,$query6);
		
		echo "
		<div align='center'>
		<table width='1058' height='20' border='0'>
		
		<h2 style='color:#414040'><u>ADITYA CATERERS</u></h2>
		";
		while($row=mysqli_fetch_array($result1))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Total Mess Fees:</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['total']."/-</center></td>";
			echo "</tr></table>";
		}

		while($row=mysqli_fetch_array($result2))
		{
			echo "<table width='1058' height='204' border='0'>
			<h2 style='color:#414040'><u>Additional Charges(not mandatory)</u></h2>
			<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Milk Charges(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['milk']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result3))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Non Veg Charges(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['nonveg']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result4))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Icecreams and Sweets(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['icensweet']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result5))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Soft Drinks(per occasion):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['softdrinks']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result6))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Room Servings(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['roomservings']."/-</center></td>";
			echo "</tr>";
		}
		echo "</table></div>";
	}

	if($mess==3)
	{
		$con=mysqli_connect("localhost","root","padmaja11@","hostel");
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		$query1="SELECT total from messfee where messid=3";
		$result1=mysqli_query($con,$query1);
		$query2="SELECT milk from messfee where messid=3";
		$result2=mysqli_query($con,$query2);
		$query3="SELECT nonveg from messfee where messid=3";
		$result3=mysqli_query($con,$query3);
		$query4="SELECT icensweet from messfee where messid=3";
		$result4=mysqli_query($con,$query4);
		$query5="SELECT softdrinks from messfee where messid=3";
		$result5=mysqli_query($con,$query5);
		$query6="SELECT roomservings from messfee where messid=3";
		$result6=mysqli_query($con,$query6);
		
		echo "
		<div align='center'>
		<table width='1058' height='20' border='0'>
		
		<h2 style='color:#414040'><u>MANIKANTA CATERERS</u></h2>
		";
		while($row=mysqli_fetch_array($result1))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Total Mess Fees:</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['total']."/-</center></td>";
			echo "</tr></table>";
		}

		while($row=mysqli_fetch_array($result2))
		{
			echo "<table width='1058' height='204' border='0'>
			<h2 style='color:#414040'><u>Additional Charges(not mandatory)</u></h2>
			<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Milk Charges(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['milk']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result3))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Non Veg Charges(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['nonveg']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result4))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Icecreams and Sweets(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['icensweet']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result5))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Soft Drinks(per occasion):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['softdrinks']."/-</center></td>";
			echo "</tr>";
		}
		while($row=mysqli_fetch_array($result6))
		{
			echo "<tr>";
			echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Room Servings(per month):</center></td>';
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['roomservings']."/-</center></td>";
			echo "</tr>";
		}
		echo "</table></div>";
	}

}

?>