<?php
echo '<body>
<div align="center">
<h1 style="color:#414040"><u>ROOM FEES</u></h1>
<form method="POST">
<select name="hostel" class="form-control" required="required" style="height:40px; font-weight:bold; font-size:20px">
<option value="">Select Type of Room</option>
<option value="1">Single Seater</option>
<option value="2">Double Seater</option>
<option value="3">Triple Seater</option>
<option value="4">Single Seater(AC)</option>
<option value="5">Double Seater(AC)</option>
<option value="6">Triple Seater(AC)</option>
</select>
<input type="submit" name="submit" Value="Get Room Fee" class="btn btn-primary" style="height:40px; font-weight:bold; font-size:20px">
</form>
</div>
</body>';
if(isset($_POST['submit']))
{
  $hostel=$_POST['hostel'];
  if($hostel==1)
  {
    $con=mysqli_connect("localhost","root","padmaja11@","hostel");
    if (mysqli_connect_errno())
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    $query1="SELECT first from roomfee where roomid=1";
    $result1=mysqli_query($con,$query1);
    $query2="SELECT second from roomfee where roomid=1";
    $result2=mysqli_query($con,$query2);
    $query3="SELECT third from roomfee where roomid=1";
    $result3=mysqli_query($con,$query3);
    $query4="SELECT total from roomfee where roomid=1";
    $result4=mysqli_query($con,$query4);
    
    echo "
    <div align='center'>
    <table width='1058' height='204' border='0'>
    
    <h2 style='color:#414040'><u>SINGLE SEATER</u></h2>
    ";
    while($row=mysqli_fetch_array($result1))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>First Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['first']."/-</center></td>";
      echo "</tr>";
    }

    while($row=mysqli_fetch_array($result2))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Second Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['second']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result3))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Third Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['third']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result4))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Total Room Fee(per semester):</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['total']."/-</center></td>";
      echo "</tr>";
    }
    
    echo "</table></div>";
  }


  if($hostel==2)
  {
    $con=mysqli_connect("localhost","root","padmaja11@","hostel");
    if (mysqli_connect_errno())
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    $query1="SELECT first from roomfee where roomid=2";
    $result1=mysqli_query($con,$query1);
    $query2="SELECT second from roomfee where roomid=2";
    $result2=mysqli_query($con,$query2);
    $query3="SELECT third from roomfee where roomid=2";
    $result3=mysqli_query($con,$query3);
    $query4="SELECT total from roomfee where roomid=2";
    $result4=mysqli_query($con,$query4);
    
    echo "
    <div align='center'>
    <table width='1058' height='204' border='0'>
    
    <h2 style='color:#414040'><u>DOUBLE SEATER</u></h2>
    ";
    while($row=mysqli_fetch_array($result1))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>First Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['first']."/-</center></td>";
      echo "</tr>";
    }

    while($row=mysqli_fetch_array($result2))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Second Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['second']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result3))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Third Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['third']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result4))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Total Room Fee(per semester):</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['total']."/-</center></td>";
      echo "</tr>";
    }
    
    echo "</table></div>";
  }

  if($hostel==3)
  {
    $con=mysqli_connect("localhost","root","padmaja11@","hostel");
    if (mysqli_connect_errno())
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    $query1="SELECT first from roomfee where roomid=3";
    $result1=mysqli_query($con,$query1);
    $query2="SELECT second from roomfee where roomid=3";
    $result2=mysqli_query($con,$query2);
    $query3="SELECT third from roomfee where roomid=3";
    $result3=mysqli_query($con,$query3);
    $query4="SELECT total from roomfee where roomid=3";
    $result4=mysqli_query($con,$query4);
    
    echo "
    <div align='center'>
    <table width='1058' height='204' border='0'>
    
    <h2 style='color:#414040'><u>TRIPLE SEATER</u></h2>
    ";
    while($row=mysqli_fetch_array($result1))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>First Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['first']."/-</center></td>";
      echo "</tr>";
    }

    while($row=mysqli_fetch_array($result2))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Second Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['second']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result3))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Third Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['third']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result4))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Total Room Fee(per semester):</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['total']."/-</center></td>";
      echo "</tr>";
    }
    
    echo "</table></div>";
  }

  if($hostel==4)
  {
    $con=mysqli_connect("localhost","root","padmaja11@","hostel");
    if (mysqli_connect_errno())
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    $query1="SELECT first from roomfee where roomid=4";
    $result1=mysqli_query($con,$query1);
    $query2="SELECT second from roomfee where roomid=4";
    $result2=mysqli_query($con,$query2);
    $query3="SELECT third from roomfee where roomid=4";
    $result3=mysqli_query($con,$query3);
    $query4="SELECT total from roomfee where roomid=4";
    $result4=mysqli_query($con,$query4);
    
    echo "
    <div align='center'>
    <table width='1058' height='204' border='0'>
    
    <h2 style='color:#414040'><u>SINGLE SEATER(AC)</u></h2>
    ";
    while($row=mysqli_fetch_array($result1))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>First Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['first']."/-</center></td>";
      echo "</tr>";
    }

    while($row=mysqli_fetch_array($result2))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Second Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['second']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result3))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Third Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['third']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result4))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Total Room Fee(per semester):</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['total']."/-</center></td>";
      echo "</tr>";
    }
    
    echo "</table></div>";
  }

  if($hostel==5)
  {
    $con=mysqli_connect("localhost","root","padmaja11@","hostel");
    if (mysqli_connect_errno())
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    $query1="SELECT first from roomfee where roomid=5";
    $result1=mysqli_query($con,$query1);
    $query2="SELECT second from roomfee where roomid=5";
    $result2=mysqli_query($con,$query2);
    $query3="SELECT third from roomfee where roomid=5";
    $result3=mysqli_query($con,$query3);
    $query4="SELECT total from roomfee where roomid=5";
    $result4=mysqli_query($con,$query4);
    
    echo "
    <div align='center'>
    <table width='1058' height='204' border='0'>
    
    <h2 style='color:#414040'><u>DOUBLE SEATER(AC)</u></h2>
    ";
    while($row=mysqli_fetch_array($result1))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>First Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['first']."/-</center></td>";
      echo "</tr>";
    }

    while($row=mysqli_fetch_array($result2))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Second Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['second']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result3))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Third Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['third']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result4))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Total Room Fee(per semester):</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['total']."/-</center></td>";
      echo "</tr>";
    }
    
    echo "</table></div>";
  }

  if($hostel==6)
  {
    $con=mysqli_connect("localhost","root","padmaja11@","hostel");
    if (mysqli_connect_errno())
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    $query1="SELECT first from roomfee where roomid=6";
    $result1=mysqli_query($con,$query1);
    $query2="SELECT second from roomfee where roomid=6";
    $result2=mysqli_query($con,$query2);
    $query3="SELECT third from roomfee where roomid=6";
    $result3=mysqli_query($con,$query3);
    $query4="SELECT total from roomfee where roomid=6";
    $result4=mysqli_query($con,$query4);
    
    echo "
    <div align='center'>
    <table width='1058' height='204' border='0'>
    
    <h2 style='color:#414040'><u>TRIPLE SEATER(AC)</u></h2>
    ";
    while($row=mysqli_fetch_array($result1))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>First Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['first']."/-</center></td>";
      echo "</tr>";
    }

    while($row=mysqli_fetch_array($result2))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Second Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['second']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result3))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Third Installment:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['third']."/-</center></td>";
      echo "</tr>";
    }
    while($row=mysqli_fetch_array($result4))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Total Room Fee(per semester):</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['total']."/-</center></td>";
      echo "</tr>";
    }
    
    echo "</table></div>";
  }
    echo '<center><h3 style="color:#414040"><u>ADDITIONAL CHARGES (not mandatory)</u></h3></center>';
    $query1="SELECT wifi from additionalroomfee where id=1";
    $result1=mysqli_query($con,$query1);
    $query2="SELECT oven from additionalroomfee where id=1";
    $result2=mysqli_query($con,$query2);
    $query3="SELECT fridge from additionalroomfee where id=1";
    $result3=mysqli_query($con,$query3);
    $query4="SELECT television from additionalroomfee where id=1";
    $result4=mysqli_query($con,$query4);
    echo "
    <div align='center'>
    <table width='1058' height='204' border='0'>
    ";
    while($row=mysqli_fetch_array($result1))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Wi-Fi:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['wifi']."/-</center></td>";
      echo "</tr>";
    }

    while($row=mysqli_fetch_array($result2))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Oven:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['oven']."/-</center></td>";
      echo "</tr>";
    }
    
    while($row=mysqli_fetch_array($result3))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Refrigerator:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['fridge']."/-</center></td>";
      echo "</tr>";
    }

    while($row=mysqli_fetch_array($result4))
    {
      echo "<tr>";
      echo '<td width="350" height="49" style="background-color:#CCD3FF; font-weight:bold; font-size:20px"><center>Television:</center></td>';
      echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>Rs ". $row['television']."/-</center></td>";
      echo "</tr>";
    }

    echo "</table></div>";

}

?>