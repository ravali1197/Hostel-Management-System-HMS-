
<center><b>Notice Board:</b><br><br>

College reopens on 10th January<br><br>

Sessionals to be announced soon<br><br>

Student development seminar on 14th Jan'18<br></center>