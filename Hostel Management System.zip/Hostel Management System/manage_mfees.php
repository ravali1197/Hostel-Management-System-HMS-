<?php
require('config.php');
if(isset($_POST['submit']))
{
$mess=$_POST['mess'];
$tmf=$_POST['tmf'];
$mc=$_POST['mc'];
$nvc=$_POST['nvc'];
$ics=$_POST['ics'];
$sd=$_POST['sd'];
$rs=$_POST['rs'];
$query = "UPDATE messfee SET total='$tmf', milk='$mc', nonveg='$nvc', icensweet='$ics', softdrinks='$sd', roomservings='$rs' WHERE messid='$mess'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center><h2 style='color:green'>Information Updated</h2></center>";
}
?>



<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Update Mess Fee</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
</head>

<body>

	<div>
		
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<h2 class="page-title">Update Mess Fees</h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">Fill all Info</div>
									<div class="panel-body">

<form method="post">	
<div class="form-group">
<label class="col-sm-3 control-label">Mess: </label>
<div class="col-sm-9">
<select name="mess" class="form-control" required="required">
<option value="">Select Mess</option>
<option value="1">Annapurna Caterers</option>
<option value="2">Aditya Caterers</option>
<option value="3">Manikanta Caterers</option>
</select>
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label"> Total Mess Fees </label>
<div class="col-sm-9">
<input type="Number" name="tmf" id="tmf"  class="form-control" required="required" >
<br>
</div>
</div>

<h3>Additional Mess Charges Information</h3>

<br>
<div class="form-group">
<label class="col-sm-3 control-label">Milk Charges: </label>
<div class="col-sm-9">
<input type="Number" name="mc" id="mc"  class="form-control" required="required" >
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Non-veg Charges: </label>
<div class="col-sm-9">
<input type="Number" name="nvc" id="nvc"  class="form-control">
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Icecreams and Sweets </label>
<div class="col-sm-9">
<input type="number" name="ics" id="ics"  class="form-control">
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Soft drinks(per occassion): </label>
<div class="col-sm-9">
<input type="number" name="sd" id="sd"  class="form-control">
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Room Servings: </label>
<div class="col-sm-9">
<input type="number" name="rs" id="rs"  class="form-control" required="required">
<br>
</div>
</div>

						

<div class="col-sm-6 col-sm-offset-4">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" name="submit" Value="Upadte" class="btn btn-primary">
</div>
</form>

									</div>
									</div>
								</div>
							</div>
						</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>

</html>