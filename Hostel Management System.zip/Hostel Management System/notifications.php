
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>

</body>
</html>

<?php
$a=1;
echo '<body>
	<form method="POST"> 
	<center><h1 style="color:dark blue;"> Notifications </h1>
	<input type="submit" name="submit" Value="View My Notifications" class="btn btn-primary" style="height:40px; font-weight:bold; font-size:20px"></center>
	</form>
</body>
';
$id=$_SESSION['user'];
//echo "$id";
if(isset($_POST['submit']))
	{
		$con=mysqli_connect("localhost","root","padmaja11@","hostel");
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		$query1="SELECT msg from notifications where touser=$id";
		$result1=mysqli_query($con,$query1);
		$rowcount=mysqli_num_rows($result1);
		//echo "$rowcount";
		//$row=mysqli_fetch_array($result1);
		if($rowcount==0)
		{
			echo "<div align='center'>
		<table width='1058' height='20' border='0'>
		";
		echo "<tr>";
			echo "<td width='872' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'><center>No notifications to view</center></td>";
			echo "</tr></table>";
			//echo "No notifications to view";
		}
		else{
			$query2="SELECT msg from notifications where touser=$id";
			$result2=mysqli_query($con,$query2);
			echo "
			<div align='center'>
			<table width='1058' height='20' border='0'>
		
		<h2 style='color:#414040'><u>Here are your messages received from Admin</u></h2>
		";
		while($row=mysqli_fetch_array($result2))
		{	
			//$a=$a+1;
			echo "<tr>";
			echo "<td class='hi' width='872' height='60px' style='background-color:#C0C0C0;font-weight:bold; font-size:20px'>". $row['msg']."</td>";
			echo "<td height='60px' style='background-color:#C0C0F0; font-weight:bold; font-size:20px'>";
			echo '<center>
			<button name="color" class="btn btn-primary" id="color" style="height:40px; width:120px" >Mark as Read</button>
			</center></td>';

			echo "</tr>";

		}
		echo "</table>";
	}

	}
?>


<script type="text/javascript">
clicked = true;
	$(document).ready(function(){
        $("button").click(function(){
            if(clicked){
                //$(this).css('background-color', 'green');
                $(this).parent().parent().siblings(".hi").css( "background-color", "green" );
                $(this).parent().parent().css( "background-color", "green" );

                //clicked  = false;
            } else {
                $(this).css('background-color', 'blue');
                //clicked  = true;
            }   
        });
    });
</script>