<?php
require('config.php');
if(isset($_POST['submit1']))
{
$room=$_POST['hostel'];
$fi=$_POST['fi'];
$si=$_POST['si'];
$ti=$_POST['ti'];
$tot=$_POST['tot'];
$query = "UPDATE roomfee SET first='$fi', second='$si', third='$ti', total='$tot' WHERE roomid='$room'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center><h2 style='color:green'>Information Updated</h2></center>";
}


if(isset($_POST['submit']))
{
$wc=$_POST['wc'];
$oc=$_POST['oc'];
$rc=$_POST['rc'];
$tc=$_POST['tc'];
$query1 = "UPDATE additionalroomfee SET wifi='$wc', oven='$oc', fridge='$rc', television='$tc' WHERE id=1";
mysqli_query($con,$query1) or die(mysqli_error($con));
echo "<center><h2 style='color:green'>Information Updated</h2></center>";
}
?>



<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Update Room Fee</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
</head>

<body>

	<div>
		
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<h2 class="page-title">Update Room Fees</h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">Fill all Info</div>
									<div class="panel-body">

<form method="post">	
<div class="form-group">
<label class="col-sm-3 control-label">Hostel: </label>
<div class="col-sm-9">
<select name="hostel" class="form-control" required="required">
<option value="">Select Hostel</option>
<option value="1">Single Seater</option>
<option value="2">Double Seater</option>
<option value="3">Triple Seater</option>
<option value="4">Single Seater(AC)</option>
<option value="5">Double Seater(AC)</option>
<option value="6">Triple Seater(AC)</option>
</select>
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label"> First Installment: </label>
<div class="col-sm-9">
<input type="Number" name="fi" id="fi"  class="form-control" required="required" >
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label"> Second Installment: </label>
<div class="col-sm-9">
<input type="Number" name="si" id="si"  class="form-control" required="required" >
<br>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"> Third Installment: </label>
<div class="col-sm-9">
<input type="Number" name="ti" id="ti"  class="form-control" required="required" >
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Total: </label>
<div class="col-sm-9">
<input type="Number" name="tot" id="tot"  class="form-control" required="required" >
<br>
</div>
</div>

<div class="col-sm-6 col-sm-offset-4">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" name="submit1" Value="Update" class="btn btn-primary">
<br>
</div>
</form>

<form method="POST">
<div>
<h2>....................Update Additional Charges Information..................</h2>
</div>
<br>
<div class="form-group">
<label class="col-sm-3 control-label">Wi-Fi Charges: </label>
<div class="col-sm-9">
<input type="Number" name="wc" id="wc"  class="form-control" required="required" >
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Oven Charges: </label>
<div class="col-sm-9">
<input type="Number" name="oc" id="oc"  class="form-control">
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Refrigerator Charges: </label>
<div class="col-sm-9">
<input type="number" name="rc" id="rc"  class="form-control">
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Television Charges: </label>
<div class="col-sm-9">
<input type="number" name="tc" id="tc"  class="form-control">
<br>
</div>
</div>


						

<div class="col-sm-6 col-sm-offset-4">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" name="submit" Value="Update" class="btn btn-primary">
</div>
</form>

									</div>
									</div>
								</div>
							</div>
						</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>

</html>