<head>
	<link rel="stylesheet" href="site/css/bootstrap.min.css">
    <link rel="stylesheet" href="site/css/normalize.min.css">
    <link rel="stylesheet" href="site/css/font-awesome.min.css">
    <link rel="stylesheet" href="site/css/animate.css">
    <link rel="stylesheet" href="site/css/templatemo_misc.css">
    <link rel="stylesheet" href="site/css/templatemo_style.css">

    <script src="site/js/vendor/modernizr-2.6.2.min.js"></script>
    <script src="site/js/vendor/jquery-1.10.1.min.js"></script>
    <script>window.jQuery || document.write('<script src="site/js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
    <script src="site/js/jquery.easing-1.3.js"></script>
    <script src="site/js/bootstrap.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="site/js/plugins.js"></script>


    <script src="site/js/main.js"></script>
    <!-- templatemo 401 sprint -->


</head>


<body>
<div id="contact" class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="section-title">Contact Us</h1>
                </div> <!-- /.col-md-12 -->
            </div> <!-- /.row -->
            <div class="row">

                <div class="col-md-6 col-sm-6">
                    <div id="mapdiv" style="overflow:hidden;"><div id="gmap_canvas" style="height:300px;width:560px;">
                    	<img src="img.png" alt="hello" height="280px">
                    </div>
                        </div>

                </div> <!-- /.col-md-6 -->
                <div class="col-md-6 col-sm-6">
                    
                    <div class="row contact-form">
                    
                        <fieldset class="col-md-6 col-sm-6">
                            <input id="name" type="text" name="name" placeholder="Name">
                        </fieldset>
                        <fieldset class="col-md-6 col-sm-6">
                            <input type="email" name="email" id="email" placeholder="Email">
                        </fieldset>
                        <fieldset class="col-md-12">
                            <input type="text" name="subject" id="subject" placeholder="Subject">
                        </fieldset>
                        <fieldset class="col-md-12">
                            <textarea name="comments" id="comments" placeholder="Message"></textarea>
                        </fieldset>
                        <fieldset class="col-md-12">

                                <button id="submit" name="send" class="btn btn-primary"><i class="glyphicon glyphicon-envelope"></i> Send</button>
                        </fieldset>
                     
                    </div> <!-- /.contact-form -->
                    
                </div> <!-- /.col-md-6 -->
            </div> <!-- /.row -->
        </div> <!-- /.container -->
    </div> <!-- /#products -->
    </body>
