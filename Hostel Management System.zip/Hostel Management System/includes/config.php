<?php
$dbuser="root";
$dbpass="padmaja11@";
$host="localhost";
$db="hostel";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>