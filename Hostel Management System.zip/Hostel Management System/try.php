<?php
echo '<body>
<form method="POST">
<select name="mess" class="form-control" required="required">
<option value="">Select Mess</option>
<option value="1">Annapurna Caterers</option>
<option value="2">Aditya Caterers</option>
<option value="3">Manikanta Caterers</option>
</select>
<input type="submit" name="submit" Value="Get Mess Fee" class="btn btn-primary">
</form>
</body>';
if(isset($_POST['submit']))
{
	$mess=$_POST['mess'];
	if($mess==1)
	{
		$con=mysqli_connect("localhost","root","padmaja11@","hostel");
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		$query="SELECT total from messfee where messid=1";
		$result=mysqli_query($con,$query);
		echo "<table border='1'>
		<tr colspan='2'>
		<th>Annapurna Caterers</th>
		</tr>";
		while($row=mysqli_fetch_array($result))
		{
			echo "<tr>";
			echo "<td>Total Fee:</td>";
			echo "<td>". $row['total']."</td>";
			echo "</tr>";
		}
		echo "</table>";
	}
}

?>