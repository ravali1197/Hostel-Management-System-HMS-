<?php

//connectivity
require('config.php');


if(isset($_POST['login']))
{
	$u = $_POST['uname'];
	$pass = $_POST['upass'];
	$username=$_POST['username'];
	//$p = md5($pass);
	$type=$_POST['pos'];
	$_SESSION['user']=$u;
	$_SESSION['pass']=$pass;
	$_SESSION['username']=$username;
//user check
$q = "SELECT * FROM users WHERE id='$u' AND password='$pass' AND username='$username'";
$q1="SELECT username FROM users WHERE id='$u'";
$cq = mysqli_query($con,$q);
$ret = mysqli_num_rows($cq);
if($ret == true)
{
	if($type=='a')
	{
	echo "<script>document.location='profile_admin.php'</script>";
	}
	else if($type=='s')
	{
	echo "<script>document.location='profile.php'</script>";
	}
	//echo "<center><h2 style='color:green'>ACCESS GRANTED</h2></center>";
}
else
{
	echo "<center><h2 style='color:red'>ACCESS DENIED</h2></center>";
}
}

?>
<html>
<body style="background-color:#E5E5E5">
<div align="center">
<form method="post">
<fieldset style="display: inline-flex; background-color: #D8D8D8;"><legend><font size="+2"><strong>Login Panel</strong></font></legend><p><b>ID or Reg.No : </b><input type="text" name="uname" required/>*</p>
</legend><p><b>Username : </b><input type="text" name="username" required/>*</p>
<p><b>Password : </b><input type="password" name="upass" required/>*</p><br>
<p><b>Select : </b><input style="border-radius: 25px" type="radio" name="pos" value="a">Admin&nbsp;<input type="radio" name="pos" value="s">Student&nbsp;<input type="radio" name="pos" value="w">Worker</p>
<p><input type="submit" value="Login" name="login"/></p>
</fieldset>
</form>
</div>
</body>
</html> 