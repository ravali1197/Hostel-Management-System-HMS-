<?php
require('config.php');
if(isset($_POST['submit']))
{
$id=$_POST['ei'];
$en=$_POST['en'];
$ed=$_POST['ed'];
$date=$_POST['date'];
$ven=$_POST['ven'];
$in=$_POST['in'];
$co=$_POST['co'];
$query = "INSERT INTO events VALUES ('$id', '$en', '$ed','$date','$ven','$in','$co')";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center><h2 style='color:green'>Event Added</h2></center>";
}
?>



<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Events</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
</head>

<body>

	<div>
		
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<h2 class="page-title">Upcoming Events</h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">Fill all Information</div>
									<div class="panel-body">

<form method="post">	
<div class="form-group">
<label class="col-sm-3 control-label"> Event ID </label>
<div class="col-sm-9">
<input type="number" name="ei" id="ei"  class="form-control" required="required" >
<br>
</div>
</div>


<div class="form-group">
<label class="col-sm-3 control-label"> Event Name </label>
<div class="col-sm-9">
<input type="text" name="en" id="en"  class="form-control" required="required" >
<br>
</div>
</div>


<div class="form-group">
<label class="col-sm-3 control-label">Description </label>
<div class="col-sm-9">
<textarea name="ed" id="ed" class="form-control" required="required" rows="5" cols="20"></textarea>
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Date: </label>
<div class="col-sm-9">
<input type="text" name="date" id="date"  class="form-control">
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Venue: </label>
<div class="col-sm-9">
<input type="text" name="ven" id="ven"  class="form-control">
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Incharge: </label>
<div class="col-sm-9">
<input type="text" name="in" id="in"  class="form-control">
<br>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label">Contact: </label>
<div class="col-sm-9">
<input type="tel" name="co" id="co"  class="form-control" required="required">
<br>
</div>
</div>

						

<div class="col-sm-6 col-sm-offset-4">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" name="submit" Value="Add Event" class="btn btn-primary">
</div>
</form>

									</div>
									</div>
								</div>
							</div>
						</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>

</html>