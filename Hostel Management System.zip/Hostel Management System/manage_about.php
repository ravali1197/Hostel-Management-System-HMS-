<?php
//connectivity
require('config.php');
if(isset($_POST['submit']))
{
	$tag=$_POST['tag'];
	$c_name=$_POST['c_name'];
	$intro=$_POST['intro'];
	$f_info=$_POST['f_info'];
	$c_info=$_POST['c_info'];
	$query = "UPDATE admin SET marquee1='$tag', colgname='$c_name', colgintro='$intro', footerinfo='$f_info', aboutinfo='$c_info' WHERE id=1";
	mysqli_query($con,$query) or die(mysqli_error($con));
	echo "<center><h2 style='color:green'>Information Updated</h2></center>";
}


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div>
	<h1 style="color: #414040" align="center"><u>UPDATE YOUR COLLEGE INFORMATION</u></h1>
	<br><br>
	<form method="post" enctype="multipart/form-data">
	<table>
	<tbody>
    <tr>
      <td width="170" height="49" style="background-color:#CCD3FF"><center><font size="+1"><b>Tag Line</b></font></center></td>
      <td width="872" style="background-color:#C0C0C0"><center><input type="text" name="tag" style="border-radius: 15px; width:600px; height:35px"></center></td>
    </tr>
    <tr>
      <td width="170" height="49" style="background-color:#CCD3FF"><center><font size="+1"><b>College Name</b></font></center></td>
      <td width="872" style="background-color:#C0C0C0"><center><input type="text" name="c_name" style="border-radius: 15px; width:600px; height:35px"></center></td>
    </tr>
    <tr>
      <td width="170" height="49" style="background-color:#CCD3FF"><center><font size="+1"><b>Footer Information</b></font></center></td>
      <td width="872" style="background-color:#C0C0C0"><center><input type="text" name="f_info" style="border-radius: 15px; width:600px; height:35px"></center></td>
    </tr>
    <tr>
      <td width="170" height="49" style="background-color:#CCD3FF"><center><font size="+1"><b>Introduction</b></font></center></td>
      <td width="872" style="background-color:#C0C0C0"><center><textarea name="intro" rows="5" cols="72" style="border-radius: 15px"></textarea></center></td>
    </tr>
    <tr>
      <td width="170" height="49" style="background-color:#CCD3FF"><center><font size="+1"><b>College Information</b></font></center></td>
      <td width="872" style="background-color:#C0C0C0"><center><textarea name="c_info" rows="5" cols="72" style="border-radius: 15px"></textarea></center></td>
    </tr>
    <tr>
      <td style="background-color:#CCD3FF; height: 40px;" colspan="2"><center><input type="submit" name="submit" value="UPDATE" style="height: 40px; width: 100px;"></center></td>
    </tr>
    </tbody>
	</table>
	</form>
</div>
</body>
</html>