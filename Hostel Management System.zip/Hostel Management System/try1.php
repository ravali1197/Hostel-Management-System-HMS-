
echo '
<div align="center"
<form method="POST">
<select name="hostel" class="form-control" required="required" style="height:40px; font-weight:bold; font-size:20px">
<option value="">Select Type of Room</option>
<option value="1">Single Seater</option>
<option value="2">Double Seater</option>
<option value="3">Triple Seater</option>
<option value="4">Single Seater(AC)</option>
<option value="5">Double Seater(AC)</option>
<option value="6">Triple Seater(AC)</option>
</select>
<input type="submit" name="submit2" Value="GET FEE DETAILS" class="btn btn-primary" style="height:40px; font-weight:bold; font-size:20px">
</form>
</div>';

if(isset($_POST['submit2']))
{
  echo "hi";
}
  /*$hostel=$_POST['hostel'];
  if($hostel==1)
  {
    $con=mysqli_connect("localhost","root","padmaja11@","hostel");
    if (mysqli_connect_errno())
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
  $query1="SELECT first from roomfee where roomid=1";
    $result1=mysqli_query($con,$query1);
    $query2="SELECT second from roomfee where roomid=1";
    $result2=mysqli_query($con,$query2);
    $query3="SELECT third from roomfee where roomid=1";
    $result3=mysqli_query($con,$query3);
    $query4="SELECT total from roomfee where roomid=1";
    $result4=mysqli_query($con,$query4);
    echo '<div align="center">
    <h1 style="color:#414040"><u>PAY FEES</u></h1>
    <form method="POST">
    <select name="pay" class="form-control" required="required" style="height:40px; font-weight:bold; font-size:20px">
    <option value="">Select Installment</option>
    <option value="1">First Installment</option>
    <option value="2">Second Installment</option>
    <option value="3">Third Installment</option>
    </select>
    <input type="submit" name="submit1" Value="PAY FEES" class="btn btn-primary" style="height:40px; font-weight:bold; font-size:20px">
    </form>
    ';

  if(isset($_POST['submit1']))
  {
    $pay=$_POST['pay'];
    if($pay==1)
    {
      //$query="SELECT insone from payroomfee where id="
    }
  }


  }*/
