<?php
require('config.php');
if(isset($_POST['submit']))
{
$si=$_POST['si'];
$msg=$_POST['msg'];
$query = "INSERT INTO notifications (msg, touser) VALUES ('$msg', '$si')";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center><h2 style='color:green'>Message Sent</h2></center>";
}
?>



<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Send Notifications</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
</head>

<body>

	<div>
		
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<h2 class="page-title">Notifications</h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">Fill the details</div>
									<div class="panel-body">

<form method="post">	


<div class="form-group">
<label class="col-sm-3 control-label">Student ID: </label>
<div class="col-sm-9">
<?php
$con = mysqli_connect("localhost","root","padmaja11@","hostel");
$sql = "SELECT id FROM users";
$result=mysqli_query($con,$sql);
echo "<select name='si'>";
echo "<option value=''> Select student ID</option>";
while ($row = mysqli_fetch_array($result)) {
    echo "<option value='" . $row['id'] ."'>" . $row['id'] ."</option>";
}
echo "</select><br>";

?>
<br>
</div>
</div>




<div class="form-group">
<label class="col-sm-3 control-label">Message: </label>
<div class="col-sm-9">
<textarea name="msg" id="msg" class="form-control" required="required" rows="5" cols="20"></textarea>
<br>
</div>
</div>


						

<div class="col-sm-6 col-sm-offset-4">
<button class="btn btn-default" type="submit">Cancel</button>
<input type="submit" name="submit" Value="Send Message" class="btn btn-primary">
</div>
</form>

									</div>
									</div>
								</div>
							</div>
						</div>
							</div>
						</div>
					</div>
				</div> 	
			</div>
		</div>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>

</html>