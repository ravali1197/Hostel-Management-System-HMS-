<center><h1>Campus Drive</h1></center>

<center>Panipat (St.Joseph's College) - <b>Accenture</b> - 17th March '18<br><br>

Allahabad (IIIT Alhbd) - <b>Wipro</b> - 28th March '18<br><br>

Lucknow (IET Lucknow) - <b>TCS</b> - 8th April '18<br><br>

Noida (JSS AMCET)- <b>Syntel</b> - 18th April '18</center>